import { Select, Radio, RadioGroup, Stack, Textarea, Button } from "@chakra-ui/react";
import React from "react";
import "./Student.css";

function Student() {
  const questions = [
    "المقرر مشوق",
    "المقرر يتضمن معلومات حديثة",
    "المقرر يرتبط بالتخصص ",
    "المقرر يقابل توقعاتى",
    "المقرر مفيد فى التطبيق العملى",
    "المقرر عموما هادف",
    "المقرر له اهداف واضحة ومعلنة",
    "المقرر مفهوم/يزودني بالمعرفة والفهم المتعمق للموضوع",
    " المقرر يحفزني على التفكير",
    "اكسبني المقرر بعض المهارات التقنية التى تفيد فى الحياة\n          المهنية",
    "يتوافر بالكلية معامل كافية لتحقيق اهداف العملية التعلمية",
    "يوجد بالمعامل الاجهزة والمعدات الحديثة",
    "يتصف تصميم المعامل بطريقة ملائمة",
    "يتصف الفنيون بالمعامل بالكفاءة العالية",
    "تعتبر المساحة المتاحة للمعامل مناسبة لأعداد الطلاب",
    "موقع المدرجات وقاعات التدريس مناسب",
    "حجم المدرجات وقاعات التدريس مناسب",
    "عدد المقاعد مناسب",
    "تسهيلات التدريس (السبورة-البروجيكتور) متاحة",
    "الهدوء بالمدرجات والفصول",
    "الاضاءة بالمدرجات والفصول",
    "النظافة بالمدرجات والفصول",
    "سهولة ابداء الراى فى المادة العلمية",
    "سهولةالتواصل مع اعضاء هيئة التدريس والهيئة المعاونة",
    "هل يتم توفير طريقة اخري لعضو هيئة التدريس من اجل التواصل معه فى\n          اسئلة الطلاب",
    "احب فى هذا المقرر",
    "لا احب فى هذا المقرر",
    "فى رايك كيف يمكن تحسين هذا المقرر",
  ];

  const lecQuestiosn = [
    "تساهم المحاضرات فى فهم موضوعات المقرر",
  "تغطى المحاضرات كل الموضوعات المشتملة فى محتوى المقرر",
  "يتم تقديم المحاضرات وفقاً لمواعيد الجداول المحددة والمعلنة",
  "تتضمن المحاضرات المشاركة من جانب الطلاب",
  "اشتملت المحاضرة على حالات وأمثلة عملية",
  "يستغل المحاضر وقت المحاضرة الفعلى فى التدريس",
  "يبدو المحاضر ذو معرفة عالية بموضوع المقرر (مستعد جيدا)\n          للمحاضرات",
  "يحافظ المحاضر على جذب انتباهي",
  "يعامل المحاضر الطلاب باحترام",
  " يقدم المحاضر امثلة وحالات عملية فعلية لموضوعات المقرر",
  "يعتبر دور الهيئة المعاونة فعالاً",
  "يبدو عضو الهيئة ملمآ بموضوعات المقرر",
  "يوفر عضو الهيئة المعاونة لنا التطبيقات الكافية",
  "يلتزم عضو الهيئة المعاونة بمواعيد المعمل المعلنة فى الجدول",
  "\n          يقوم عضو الهيئة المعاونة بالربط بين الج…ظرى الذي\n          تم تدريسه فى المحاضرة\n        ",
  "يقدم عضو الهيئة المعاونة المساعدة لكل طالب عند الحاجة لذلك"
  ];

  const section = [
    "يعتبر دور الهيئة المعاونة فعالاً",
    "يبدو عضو الهيئة ملمآ بموضوعات المقرر",
    "يوفر عضو الهيئة المعاونة لنا التطبيقات الكافية",
    "يلتزم عضو الهيئة المعاونة بمواعيد المعمل المعلنة فى الجدولا",
    "يقدم عضو الهيئة المعاونة المساعدة لكل طالب عند الحاجة لذلك"
  ]

  const exam = ["يعتبر دور الهيئة المعاونة فعالاً",
  "يبدو عضو الهيئة ملمآ بموضوعات المقرر",
  "يوفر عضو الهيئة المعاونة لنا التطبيقات الكافية",
  "يلتزم عضو الهيئة المعاونة بمواعيد المعمل المعلنة فى الجدول",
  "\n          يقوم عضو الهيئة المعاونة بالربط بين الج…ظرى الذي\n          تم تدريسه فى المحاضرة\n        ",
  "يقدم عضو الهيئة المعاونة المساعدة لكل طالب عند الحاجة لذلك"]

  const labs = [
    "يتوافر بالكلية معامل كافية لتحقيق اهداف العملية التعلمية",
    "يوجد بالمعامل الاجهزة والمعدات الحديثة",
    "يتصف تصميم المعامل بطريقة ملائمة",
    "يتصف الفنيون بالمعامل بالكفاءة العالية",
    "موقع المدرجات وقاعات التدريس مناسب",
    "حجم المدرجات وقاعات التدريس مناسب",
    "عدد المقاعد مناسب",
    "تسهيلات التدريس (السبورة-البروجيكتور) متاحة",
    "الهدوء بالمدرجات والفصول",
    "الاضاءة بالمدرجات والفصول",
    "النظافة بالمدرجات والفصول"
  ]

  const communicate= [
    "سهولة ابداء الراى فى المادة العلمية",
    "سهولةالتواصل مع اعضاء هيئة التدريس والهيئة المعاونة",
    "هل يتم توفير طريقة اخري لعضو هيئة التدريس من اجل التواصل معه فى اسئلة الطلاب"
  ]

  const opinion = [
    "احب فى هذا المقرر",
    "لا احب فى هذا المقرر",
    "فى رايك كيف يمكن تحسين هذا المقرر"
  ]

  const courseQuestions = questions.map(ques => (
    <RadioGroup key={ques} className='single__question'>
          <label className="radio__title">{ques}</label>
          <Stack direction="row">
            <Radio value="1">موافق تماما</Radio>
            <Radio value="2">موافق</Radio>
            <Radio value="3"> الى حد ما</Radio>
            <Radio value="4"> غير موافق</Radio>
          </Stack>
        </RadioGroup>
  ));

  const lecturesQuestions = lecQuestiosn.map(ques => (
    <RadioGroup key={ques} className='single__question'>
          <label className="radio__title">{ques}</label>
          <Stack direction="row">
            <Radio value="1">موافق تماما</Radio>
            <Radio value="2">موافق</Radio>
            <Radio value="3"> الى حد ما</Radio>
            <Radio value="4"> غير موافق</Radio>
          </Stack>
        </RadioGroup>
  ));

  const sectionQuestions = section.map(ques => (
    <RadioGroup key={ques} className='single__question'>
          <label className="radio__title">{ques}</label>
          <Stack direction="row">
            <Radio value="1">موافق تماما</Radio>
            <Radio value="2">موافق</Radio>
            <Radio value="3"> الى حد ما</Radio>
            <Radio value="4"> غير موافق</Radio>
          </Stack>
        </RadioGroup>
  ));

  const labsQuestions = labs.map(ques => (
    <RadioGroup key={ques} className='single__question'>
          <label className="radio__title">{ques}</label>
          <Stack direction="row">
            <Radio value="1">موافق تماما</Radio>
            <Radio value="2">موافق</Radio>
            <Radio value="3"> الى حد ما</Radio>
            <Radio value="4"> غير موافق</Radio>
          </Stack>
        </RadioGroup>
  ));

  const commQuestions = communicate.map(ques => (
    <RadioGroup key={ques} className='single__question'>
          <label className="radio__title">{ques}</label>
          <Stack direction="row">
            <Radio value="1">موافق تماما</Radio>
            <Radio value="2">موافق</Radio>
            <Radio value="3"> الى حد ما</Radio>
            <Radio value="4"> غير موافق</Radio>
          </Stack>
        </RadioGroup>
  ));

  const opinionQuestions = opinion.map(op => {
    return (<div className="single__question" key={op}>
    <label className="radio__title">{op}</label>
    <Textarea placeholder='here' />
  </div>)
  })

  return (
    <main id="studentPage">
      <h1 className="page__title">نتائج استبيان المقرر الدراسي</h1>

      <div className="course__name">
        <h3>اسم المادة</h3>
        <Select placeholder="اختر الدكتور">
          <option className="select__box" value="option1">
            د. أحمد النجار
          </option>
          <option className="select__box" value="option2">
            د. نهى يحيى
          </option>
          <option className="select__box" value="option3">
            د. كريم أحمد
          </option>
          <option className="select__box" value="option3">
            د. عمرو محمد
          </option>
          <option className="select__box" value="option3">
            د. حاتم نعمان{" "}
          </option>
          <option className="select__box" value="option3">
            د. حمدي عبدالسميع{" "}
          </option>
          <option className="select__box" value="option3">
            د.محمد العربي
          </option>
          <option className="select__box" value="option3">
            د.عبدالرحيم محمد
          </option>
        </Select>
      </div>

      <div className="quest">
        <h1 className="sec__head">المقرر</h1>
        {courseQuestions}

        <h1 className="sec__head">المحاضرة</h1>
        {lecturesQuestions}

        <h1 className="sec__head">السكشن</h1>
        {sectionQuestions}

        <h1 className="sec__head">المعامل</h1>
        {labsQuestions}

        <h1 className="sec__head">التواصل</h1>
        {commQuestions}

        <h1 className="sec__head">رأيك</h1>
        {opinionQuestions}
      </div>

      <Button colorScheme='green' className="submit__questions">إرسال</Button>
    </main>
  );
}

export default Student;
