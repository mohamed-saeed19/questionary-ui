import { FormControl, FormLabel, Input, FormErrorMessage } from "@chakra-ui/react";
import { Button, ButtonGroup } from "@chakra-ui/react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Login.css"
import axios from "axios";

function Login() {

  const [national, setNational] = useState("");
  const [studentCode, setStudentCode] = useState("");
  const [pwd, setPwd] = useState("");
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleLogin = (e, type) => {
    if(!national || !studentCode || !pwd) {
      return setError("all inputs are required");
    }
    setError("");

    // axios get await ...etc

    if(type === 'student') {
      navigate("/student", {replace: true});
    }
  }
  // import { Select } from '@chakra-ui/react'
  return (
    <div id="login">
      <FormControl isInvalid={error} className='login__form'>
        <FormLabel>National ID</FormLabel>
        <Input type="number" value={national} onChange={e => setNational(e.target.value)} />

        <FormLabel>Student Code</FormLabel>
        <Input type="number" onChange={e => setStudentCode(e.target.value)} />

        <FormLabel>Password</FormLabel>
        <Input type="password"  onChange={e => setPwd(e.target.value)} />

        {
          error && <FormErrorMessage className="error__msg">{error}</FormErrorMessage>
        }

        <ButtonGroup className="buttons__group">
          <Button colorScheme="teal" onClick={(e) => handleLogin(e, 'student')}>Login as a Student</Button>
          <Button colorScheme="gray" onClick={(e) => handleLogin(e, 'doctor')}>Login as a Doctor</Button>
        </ButtonGroup>
      </FormControl>
    </div>
  );
}

export default Login;
