import { useState } from 'react'
import { Routes, Route } from 'react-router-dom'
import reactLogo from './assets/react.svg'
import Login from './Components/Login'
import Student from './Components/Student'
import viteLogo from '/vite.svg'

function App() {
  const [count, setCount] = useState(0)

  return (
    <div className="App">
      <Routes>
        <Route path='/login' element={<Login />} />
        <Route path='/student' element={<Student />} />
        {/* <Route path='/docotr' /> */}
      </Routes>
    </div>
  )
}

export default App
